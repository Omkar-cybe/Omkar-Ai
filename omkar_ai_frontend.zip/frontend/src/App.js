import React, { useState } from 'react';

function App() {
  const [input, setInput] = useState('');
  const [response, setResponse] = useState('');

  const sendMessage = async () => {
    const res = await fetch('https://omkar-ai-backend.onrender.com/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt: input })
    });
    const data = await res.json();
    setResponse(data.response);
  };

  return (
    <div style={{ padding: '2rem', fontFamily: 'Arial' }}>
      <h2>Omkar AI 🧠</h2>
      <input
        type="text"
        placeholder="Type a message..."
        value={input}
        onChange={e => setInput(e.target.value)}
        style={{ width: '300px', padding: '0.5rem' }}
      />
      <button onClick={sendMessage} style={{ marginLeft: '1rem' }}>Send</button>
      <p><strong>Response:</strong> {response}</p>
    </div>
  );
}

export default App;